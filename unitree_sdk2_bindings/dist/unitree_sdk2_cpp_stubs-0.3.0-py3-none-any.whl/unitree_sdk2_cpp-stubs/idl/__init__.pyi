"""DDS message namespaces."""
